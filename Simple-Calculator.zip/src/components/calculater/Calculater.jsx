import React, { useState } from 'react';
import './Calculator.css';

function Calculator() {
  const [input, setInput] = useState('');
  const [result, setResult] = useState(0);

  const handleNumberChange = (e) => {
    setInput(e.target.value);
  };

  const handleAdd = () => {
    setResult(result + parseFloat(input));
  };

  const handleSubtract = () => {
    setResult(result - parseFloat(input));
  };

  const handleMultiply = () => {
    setResult(result * parseFloat(input));
  };

  const handleDivide = () => {
    setResult(result / parseFloat(input));
  };

  const handleResetInput = () => {
    setInput('');
  };

  const handleResetResult = () => {
    setResult(0);
  };

  return (
    <div className="calculator">
      <h1>Simple Calculator</h1>
      <input
        type="number"
        value={input}
        onChange={handleNumberChange}
        placeholder="Enter a number"
      />
      <div className="buttons">
        <button onClick={handleAdd}>Add</button>
        <button onClick={handleSubtract}>Subtract</button>
        <button onClick={handleMultiply}>Multiply</button>
        <button onClick={handleDivide}>Divide</button>
        <button onClick={handleResetInput}>Reset Input</button>
        <button onClick={handleResetResult}>Reset Result</button>
      </div>
      <div className="result">
        <p>Result: {result}</p>
      </div>
    </div>
  );
}

export default Calculator;
