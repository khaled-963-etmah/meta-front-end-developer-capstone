import React from "react";
import Calculator from "./components/calculater/Calculater";


function App() {
  return (
    <div className="App">
      <Calculator />
    </div>
  );
}

export default App;
